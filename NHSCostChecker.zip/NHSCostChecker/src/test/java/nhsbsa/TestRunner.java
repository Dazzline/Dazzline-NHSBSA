package nhsbsa;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(
		features = "src/test/resources/featurefiles/NHSCostsChecker.feature",
		tags="@RunTest",
		monochrome = true,
		plugin = {"pretty" ,"html:target/cucumber-report/cucumber.html" ,"json:target/json-cucumber-report/cucumber.json" }
		)

public class TestRunner {

}
