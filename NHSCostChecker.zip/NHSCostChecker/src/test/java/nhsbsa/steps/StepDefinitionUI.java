package nhsbsa.steps;

import java.io.IOException;

import org.junit.Assert;
import org.openqa.selenium.WebElement;

import com.nhsbsa.pages.CostsCheckerPage;
import com.nhsbsa.utility.Configuration;
import com.nhsbsa.utility.CostsCheckerUtilityPage;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class StepDefinitionUI {
	
	public String startUrl;
	public Boolean Result ;
	public String landingUrlPropFilePath = ".//Checker_TestData//PropertyFiles//NaviagtionUrl.properties";
	
	CostsCheckerUtilityPage cost_checker = CostsCheckerUtilityPage.getInstance();
	CostsCheckerPage cost_checker_actions = new CostsCheckerPage();
	Configuration config_properties = Configuration.getInstance();
	
	
	@Given("^User Navigates to Nhs costs checker tool$")
	public void nhsCostsCheckerNavigation() throws Exception {

		System.out.println("Entered    **************************");
		startUrl = Configuration.propertyMethod("environmentUrl");
		cost_checker.launchBrowserUrl(startUrl);		
	}
		

	@When("^User clicks on (.*)$")
	public void user_clicks(String str) {
		System.out.println("Entered user_clicks    **************************");
		if( str.contains("start")){
			cost_checker_actions.clickCookieEnabler();
			cost_checker_actions.clickStartNowButton();
		}else if(str.contains("next")) {
			cost_checker_actions.clickNextButton();
		}else if(str.contains("partner")) {
			cost_checker_actions.clickpartner_Yes();
		}else if(str.contains("dental practice country")) {
			cost_checker_actions.clickRadioEngland();
		}else if(str.contains("partner claim benefits")) {
			cost_checker_actions.clickTaxClaimBenifit();
		}else if(str.contains("universal credit take home pay")) {
			cost_checker_actions.clickUnv_credit_takeaway_yes();
		}else if(str.contains("universal credit claim")) {
			cost_checker_actions.clickUnv_creditclaim_yes();
		}else if(str.contains("paid universal credit")) {
			cost_checker_actions.clickUnv_creditPaid();
		}else if(str.contains("gp practice")) {
			cost_checker_actions.clickYesRadioButton();
		}else {
			System.out.println("Determined Action is out of Click action scope  : "+str);
			
		}
		
		
	}
	@When("^User is from (.*)$")
	public void user_select_living_place(String str) {
		System.out.println("Entered  locale place  **************************");
		if(str.contains("ENGLAND")) {
			cost_checker_actions.clickPlaceEngland();
		}else if(str.contains("WALES")) {
			cost_checker_actions.clickPlaceWales();
		}else if(str.contains("NORTHERN IRELAND")) {
			cost_checker_actions.clickPlaceNorthIreland();
		}
	}
	
	
	@When ("^User enters the date of birth as '(.+)'$")
	public void validate_and_enter_DOB(String DOB) {
		System.out.println("Entered  validate_and_enter_DOB  **************************");
		String[] Birthdate;
		Birthdate = cost_checker.dob_retrieve(DOB);
		cost_checker_actions.input_value_DOB_Day(Birthdate[0]);
		cost_checker_actions.input_value_DOB_Month(Birthdate[1]);
		cost_checker_actions.input_value_DOB_Year(Birthdate[2]);
	}
	
	@Then("^User verifies the eligibity result (.*)$")
	public void validate_costs_eligibility(String str) {
		String Result_reason ;
		System.out.println("Entered  validate_costs_eligibility  **************************");
		Result_reason = cost_checker_actions.ValidateResult();
		System.out.println("************************** "+ Result_reason+" **************************");
		Assert.assertEquals(Result_reason,"Based on what you've told us\nYou get help with NHS costs");
	}
	
	@Then("^User verifies the Landing page (.*)$")
	public void landing_page_verification(String str) throws IOException{
		String ExpectedLandingUrl = null;
		String CurrentLandingUrl = Configuration.driver.getCurrentUrl();
		System.out.println("Entered  landing_page_verification  **************************");
		
		if (str.contains("from start page")){
			ExpectedLandingUrl= cost_checker.expectedLandingUrlfetch("living_location");
		}else if (str.contains("user place selection")){
			ExpectedLandingUrl= cost_checker.expectedLandingUrlfetch("gp_practice_url");
		}else if (str.contains("gp practice selection")){
			ExpectedLandingUrl= cost_checker.expectedLandingUrlfetch("dental_practice_country");
		}else if (str.contains("dental practice country")){
			ExpectedLandingUrl= cost_checker.expectedLandingUrlfetch("dob");
		}else if (str.contains("date of birth")){
			ExpectedLandingUrl= cost_checker.expectedLandingUrlfetch("partner");
		}else if (str.contains("partner selection")){
			ExpectedLandingUrl= cost_checker.expectedLandingUrlfetch("tax_benifits");
		}else if (str.contains("partner claim benefits")){
			ExpectedLandingUrl= cost_checker.expectedLandingUrlfetch("paid_unv_credit");
		}else if (str.contains("paid universal credit")){
			ExpectedLandingUrl= cost_checker.expectedLandingUrlfetch("unv_credit_claim");
		}else if (str.contains("universal credit claim")){
			ExpectedLandingUrl= cost_checker.expectedLandingUrlfetch("unv_credit_take_home");
		}else if (str.contains("universal credit take home pay")){
			ExpectedLandingUrl= cost_checker.expectedLandingUrlfetch("result_qualify_UC");
		}else {
			System.out.println("Determined Action is out of Click action scope  : "+str);
		}	
		System.out.println(ExpectedLandingUrl);
		System.out.println(CurrentLandingUrl);
		Assert.assertTrue("The Actual Landing url differs from the Expected Landing url ", ExpectedLandingUrl.equals(CurrentLandingUrl));
		
	}
	
	@And("^User clicks next button without providing information$")
	public void click_next_without_input() {
		System.out.println("click_next_without_input  **************************");
		cost_checker_actions.clickNextButton();
	}
	
	@Then("^User validates if error message rendered$")
	public void validate_error_message_rendered() {
		System.out.println("validate_error_message_rendere  **************************");
		WebElement element;
		element = cost_checker_actions.validateErrorMessage();
		Assert.assertNotNull("The Expected Error Message Not Rendered", element);
		
	}
	
	@Then("^User verifies eligibility for selected living place as Northern Ireland$")
	public void validate_costs_eligibility_from_NorthIreland() {
		String Result_reason ;
		System.out.println("Entered  validate_costs_eligibility_from_NorthIreland  **************************");
		Result_reason = cost_checker_actions.ValidateResult_NorthIreland();
		System.out.println("************************** "+ Result_reason+" **************************");
		Assert.assertEquals(Result_reason,"You cannot use this service because you live in Northern Ireland");
	}
	
}
