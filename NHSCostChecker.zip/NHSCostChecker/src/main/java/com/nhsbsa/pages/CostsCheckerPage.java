package com.nhsbsa.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.nhsbsa.utility.CommonActions;

public class CostsCheckerPage extends CommonActions{

	public CostsCheckerPage() {
		PageFactory.initElements(driver, this);
	}

	@CacheLookup
	@FindBy(id="nhsuk-cookie-banner__link_accept_analytics")
	WebElement CookieEnabler ;
	@CacheLookup
	@FindBy(xpath = "//input[@id='next-button']")
	WebElement StartNowButton;
	@CacheLookup
	@FindBy(id="radio-england")
	WebElement PlaceEngland;
	@FindBy(id="radio-wales")
	WebElement PlaceWales;
	@FindBy(id="radio-nire")
	WebElement PlaceNorthIreland;
	@FindBy(id="next-button")
	WebElement NextButton;
	@CacheLookup
	@FindBy(xpath = "//input[@id='radio-yes']")
	WebElement YesRadioButton;
	
	@FindBy(id="radio-england")
	WebElement RadioEngland;
	
	@FindBy(id="dob-day")
	WebElement DOB_Day;
	
	@FindBy(id="dob-month")
	WebElement DOB_Month;
	
	@FindBy(id="dob-year")
	WebElement DOB_Year;
	@FindBy(id="label-yes")
	WebElement partner_Yes;
	@FindBy(id="radio-yes")
	WebElement TaxClaimBenifit;
	@FindBy(xpath = "//fieldset[@id='paidUniversalCredit_fieldset']/div/label")
	WebElement Unv_creditPaid;
	@FindBy(id="label-yes")
	WebElement Unv_creditclaim_yes;
	@FindBy(id="label-yes")
	WebElement Unv_credit_takeaway_yes;
	@CacheLookup
	@FindBy(xpath = "//div[@class='done-panel']//h2")
	WebElement fetchresult;
	@FindBy(id="result-heading")
	WebElement resultReason;
	@FindBy(id="error-summary")
	WebElement errorMessage;
	


	//  NHS costs verification setup UI actions

	public void clickCookieEnabler() {
		webElementClick(CookieEnabler);
	}
	public void clickStartNowButton() {
		webElementClick(StartNowButton);
	}
	public void clickPlaceEngland() {
		webElementClick(PlaceEngland);
	}
	public void clickPlaceWales() {
		webElementClick(PlaceWales);
	}
	public void clickPlaceNorthIreland() {
		webElementClick(PlaceNorthIreland);
	}	
	public void clickNextButton() {
		webElementClick(NextButton);
	}
	public void clickYesRadioButton() {
		webElementClick(YesRadioButton);
	}
	public void clickRadioEngland() {
		webElementClick(RadioEngland);
	}
	public void input_value_DOB_Day(String str) {
		findWebElement_clearTxt(DOB_Day);
		passTxtToWebElement(DOB_Day,str);
	}
	public void input_value_DOB_Month(String str) {
		findWebElement_clearTxt(DOB_Month);
		passTxtToWebElement(DOB_Month,str);
	}
	public void input_value_DOB_Year(String str) {
		findWebElement_clearTxt(DOB_Year);
		passTxtToWebElement(DOB_Year,str);
	}
	public void clickpartner_Yes() {
		webElementClick(partner_Yes);
	}
	public void clickTaxClaimBenifit() {
		webElementClick(TaxClaimBenifit);
	}
	public void clickUnv_creditPaid() {
		webElementClick(Unv_creditPaid);
	}
	public void clickUnv_creditclaim_yes() {
		webElementClick(Unv_creditclaim_yes);
	}
	public void clickUnv_credit_takeaway_yes() {
		webElementClick(Unv_credit_takeaway_yes);
	}
	public String ValidateResult() {
		return fetchTxtFromWebElement(fetchresult);		
	}
	public String ValidateResult_NorthIreland() {
		return fetchTxtFromWebElement(resultReason);		
	}	
	public WebElement validateErrorMessage() {
		
		return waitsForWebElementVisible(errorMessage,40);
		
	}

}
