package com.nhsbsa.utility;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class CommonActions extends Configuration{


	//*****************WEBDRIVER COMMON ACTIONS******************************//

	/**
	 * Method purpose : To click on a By element
	 */
	public void byElementClick(By element) {
		WebElement Clickable_element = driver.findElement(element);
		Clickable_element.click();
	}
	/**
	 * Method purpose : To click on a WebElement
	 */
	public void webElementClick(WebElement element) {

		element.click();

	}
	/**
	 * Method purpose : Clears the Data from the found By Element
	 */
	public void findByElement_clearTxt(By element) {
		WebElement clear_element = driver.findElement(element);
		clear_element.clear();
	}
	/**
	 * Method purpose : Clears the Data from the found WebElement
	 */
	public void findWebElement_clearTxt(WebElement element){
		element.clear();
	}
	/**
	 * Method purpose : Pass Text to a By Element
	 */
	public void passTxtToByElement(By element, String txt) {
		WebElement test_element = driver.findElement(element);
		test_element.sendKeys(txt);
	}
	/**
	 * Method purpose : Pass Text to a WebElement
	 */
	public void passTxtToWebElement(WebElement element, String txt) {
		element.sendKeys(txt);
	}

	/**
	 * Method purpose : To Fetch Text from a By element
	 */

	public String fetchTextFromByElement(By element) {

		return driver.findElement(element).getText();
	}

	/**
	 * Method purpose : To Fetch Text from a WebElement
	 */
	public String fetchTxtFromWebElement(WebElement element) {

		return element.getText();
	}
	


	/**
	 * Method purpose : To wait until By Element visible
	 */
	public WebElement waitsForByElementVisible(By element, int seconds) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(seconds));
		wait.until(ExpectedConditions.visibilityOfElementLocated(element));
		return driver.findElement(element);
	}
	/**
	 * Method purpose : To wait until WebElement visible
	 */
	public WebElement waitsForWebElementVisible(WebElement element, int seconds) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(seconds));
		wait.until(ExpectedConditions.visibilityOf(element));
		return element;
	}
	/**
	 * Method purpose : To wait until Title is Equal to expected
	 */
	public String waitsForTitleToBeEqualTo(String expectedTitle) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(60));
		wait.until(ExpectedConditions.titleContains(expectedTitle));
		return expectedTitle;
	}
	/**
	 * Method purpose : To wait until Url is Equal to expected
	 */
	public String waitsForUrlToBeEqualTo(String expectedUrl) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(60));
		wait.until(ExpectedConditions.urlToBe(expectedUrl));
		return expectedUrl;
	}
	/**
	 * Method purpose : To takescreenshot and save to a location
	 */
	public static String getScreenshot(WebDriver driver, String ImageName) {
        String date_val = new SimpleDateFormat("yyyyMMdd").format(new Date());
        TakesScreenshot take_screen= (TakesScreenshot) driver;
        File org= take_screen.getScreenshotAs(OutputType.FILE);
        String finalFilePath = System.getProperty("user.dir") + "/target/screenshots/" + ImageName + date_val + ".png";
        File finalFile = new File(finalFilePath);
        try {
            FileUtils.copyFile(org, finalFile);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return finalFilePath;
	}
}