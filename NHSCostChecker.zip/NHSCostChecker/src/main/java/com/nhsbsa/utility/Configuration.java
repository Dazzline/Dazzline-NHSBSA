package com.nhsbsa.utility;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.PageFactory;


import io.github.bonigarcia.wdm.WebDriverManager;

public class Configuration {
	

	public static Configuration instance;
	public static String prop_value;
	public static Properties env_prop = new Properties(); 
	public static File propfile = new File(".//src//main//java//com//nhsbsa//propertyfiles//Environment.properties");
	public static WebDriver driver;
	public static int implicitwaitseconds ;
	
	public Configuration() {
		PageFactory.initElements(driver, this);
	}
		
	public static Configuration getInstance() {
		if (instance == null) {
			synchronized (Configuration.class) {
				if(instance == null) {
					instance = new Configuration();
				}
				
			}
		}
		return instance;
	}
	
	public static String propertyMethod(String prop) throws IOException{
		FileInputStream file= new FileInputStream(propfile);
		try {
			env_prop.load(file);
			prop_value = env_prop.getProperty(prop);	
		}
		catch (Exception e){
			e.printStackTrace();	
		}finally {
			file.close();
		}		
		return prop_value;
	}
	
	public static String customPropertyFetchMethod(String prop,String filepath) throws IOException{
		
		String property_value = null ;
		Properties property_all = new Properties();
		
		FileInputStream file= new FileInputStream(new File(filepath));
		try {
			property_all.load(file);
			property_value = property_all.getProperty(prop);	
		}
		catch (Exception e){
			e.printStackTrace();	
		}finally {
			file.close();
		}		
		return property_value;
	}
	
	public void browserSelection() throws IOException {
		
		String browser = propertyMethod("browser");

		 
		if (browser.equalsIgnoreCase("chrome")){
			WebDriverManager.chromedriver().setup();
			driver = new ChromeDriver();
			
		}
		else if (browser.equalsIgnoreCase("firefox")) {
			WebDriverManager.firefoxdriver().setup();
			driver = new FirefoxDriver();
		}
		else {
			System.out.println("Unsupported Browser Name Detected");
		}
		
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		

	}
	public static void implicitWait() throws NumberFormatException, IOException {
		
		int seconds = Integer.parseInt(propertyMethod("implicitlyWait"));
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(seconds));
	}
	public static void closeBrowser() {
		
        if (driver != null) {
            driver.quit();
        }
    }

}
